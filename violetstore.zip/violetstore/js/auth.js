// ========================================
// AUTH.JS - Autenticación y Gestión de Usuarios
// ========================================

// Manejar envío de formulario de autenticación
function handleAuthSubmit(e) {
    e.preventDefault();
    
    // Obtener valores del formulario
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;
    const name = document.getElementById('nameInput').value;

    if (appState.isLoginMode) {
        // Modo: Iniciar Sesión
        loginUser(email, password);
    } else {
        // Modo: Registro de nuevo usuario
        registerUser(email, password, name);
    }
}

// Iniciar sesión de usuario
function loginUser(email, password) {
    // Crear objeto de usuario logueado
    appState.user = {
        email: email,
        name: 'Usuario',
        referralCode: generateReferralCode()
    };
    
    showNotification('¡Bienvenido!');
    changeView('home');
}

// Registrar nuevo usuario
function registerUser(email, password, name) {
    // Crear objeto de nuevo usuario
    appState.user = {
        email: email,
        name: name,
        referralCode: generateReferralCode()
    };
    
    showNotification('¡Cuenta creada con éxito!');
    changeView('home');
}

// Generar código de referido único
function generateReferralCode() {
    return 'REF' + Math.random().toString(36).substr(2, 6).toUpperCase();
}

// Alternar entre modo login y modo registro
function toggleAuthMode() {
    // Cambiar el modo actual
    appState.isLoginMode = !appState.isLoginMode;
    
    // Obtener elementos del DOM
    const title = document.getElementById('authTitle');
    const nameGroup = document.getElementById('nameGroup');
    const toggleBtn = document.getElementById('toggleAuthMode');
    const submitBtn = document.querySelector('#authForm button[type="submit"]');

    if (appState.isLoginMode) {
        // Configurar interfaz para modo Login
        title.textContent = 'Iniciar Sesión';
        nameGroup.classList.add('hidden');
        toggleBtn.textContent = '¿No tienes cuenta? Regístrate';
        submitBtn.textContent = 'Ingresar';
    } else {
        // Configurar interfaz para modo Registro
        title.textContent = 'Registrarse';
        nameGroup.classList.remove('hidden');
        toggleBtn.textContent = '¿Ya tienes cuenta? Inicia sesión';
        submitBtn.textContent = 'Crear Cuenta';
    }
}

// Renderizar información del perfil de usuario
function renderProfile() {
    const profileInfo = document.getElementById('profileInfo');
    const ordersList = document.getElementById('ordersList');

    // Mostrar información del usuario
    profileInfo.innerHTML = `
        <p><strong>Nombre:</strong> ${appState.user.name}</p>
        <p><strong>Email:</strong> ${appState.user.email}</p>
        <p><strong>Código de Referido:</strong> ${appState.user.referralCode}</p>
        <button class="btn logout-btn" onclick="logout()">Cerrar Sesión</button>
    `;

    // Mostrar historial de pedidos
    if (appState.orderHistory.length === 0) {
        ordersList.innerHTML = '<p style="color: #6b7280;">No tienes pedidos aún</p>';
    } else {
        ordersList.innerHTML = appState.orderHistory.map(order => `
            <div class="order-item">
                <p><strong>Pedido #${order.id}</strong></p>
                <p>Fecha: ${order.date}</p>
                <p>Total: $${order.total.toLocaleString()}</p>
                <p>Estado: <span class="order-status">${order.status}</span></p>
            </div>
        `).join('');
    }
}

// Cerrar sesión de usuario
function logout() {
    appState.user = null;
    showNotification('Sesión cerrada');
    changeView('home');
}