// ========================================
// APP.JS - Archivo Principal de la Aplicación
// Este archivo inicializa y coordina todos los módulos
// ========================================

// Inicializar la aplicación completa
async function initApp() {
    console.log('🚀 Iniciando VioletStore...');
    
    // 1. Cargar datos desde data.json
    const dataLoaded = await loadData();
    
    if (!dataLoaded) {
        showNotification('Error al cargar datos. Por favor recarga la página.', 'error');
        return;
    }
    
    // 2. Renderizar componentes iniciales de la interfaz
    renderFilters();   // Renderizar filtros de productos
    renderProducts();  // Renderizar grilla de productos
    renderBlog();      // Renderizar posts del blog
    
    // 3. Configurar todos los event listeners
    setupEventListeners();
    
    // 4. Actualizar elementos de la interfaz
    updateCartBadge(); // Actualizar contador del carrito
    
    console.log('✅ VioletStore inicializado correctamente');
}

// Configurar todos los event listeners de la aplicación
function setupEventListeners() {
    // Event listeners para navegación del header
    document.querySelectorAll('[data-view]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const view = e.target.dataset.view;
            changeView(view);
        });
    });

    // Event listener para botón del carrito
    const cartBtn = document.getElementById('cartBtn');
    if (cartBtn) {
        cartBtn.addEventListener('click', () => changeView('cart'));
    }

    // Event listener para botón de usuario
    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
        userBtn.addEventListener('click', () => {
            if (appState.user) {
                // Si hay usuario logueado, ir a perfil
                changeView('profile');
            } else {
                // Si no hay usuario, ir a login
                changeView('login');
            }
        });
    }

    // Event listener para toggle del menú móvil
    const menuToggle = document.getElementById('menuToggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            const nav = document.getElementById('mainNav');
            nav.classList.toggle('active');
        });
    }

    // Event listener para búsqueda de productos
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            handleSearch(e.target.value);
        });
    }

    // Event listener para cerrar modal de producto
    const closeModal = document.getElementById('closeModal');
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            document.getElementById('productModal').classList.remove('active');
        });
    }

    // Event listener para formulario de autenticación
    const authForm = document.getElementById('authForm');
    if (authForm) {
        authForm.addEventListener('submit', handleAuthSubmit);
    }

    // Event listener para toggle entre login y registro
    const toggleAuthBtn = document.getElementById('toggleAuthMode');
    if (toggleAuthBtn) {
        toggleAuthBtn.addEventListener('click', toggleAuthMode);
    }

    // Event listener para formulario de asesoría
    const advisorForm = document.getElementById('advisorForm');
    if (advisorForm) {
        advisorForm.addEventListener('submit', handleAdvisorSubmit);
    }

    // Event listener para click en el logo (volver a home)
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.addEventListener('click', () => changeView('home'));
    }

    console.log('✅ Event listeners configurados');
}

// Iniciar la aplicación cuando el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM cargado');
    initApp();
});